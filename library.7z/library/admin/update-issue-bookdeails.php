<?php
session_start();  
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 

if(isset($_POST['return']))
{
    $bkid1=$_SESSION['bkid'];
$dec1=$_SESSION['dec'];
$sid1=$_SESSION['sid'];
    $rid=intval($_GET['rid']);  
$fine=$_POST['fine'];
$rt1=$_SESSION['rt'];
$rstatus=1;
date_default_timezone_set('Asia/Kolkata');
$timestamp=time();
$rd=date("yy-m-d h:i:s",$timestamp);
$ustatus=NULL;
$Pstatus=2;
if($ReturnStatus==NULL)
{
$sql1="update tblissuedbookdetails set fine=:fine,ReturnStatus=:rstatus,ReturnedDate=:rd,Pstatus=:Pstatus where id=:rid;update tblbooks set status=:ustatus where id=:bkid1;update tblstudents set bookcount=:dec1 WHERE StudentId=:sid1";
$query = $dbh->prepare($sql1);
$query->bindParam(':rid',$rid,PDO::PARAM_STR);
$query->bindParam(':fine',$fine,PDO::PARAM_STR);
$query->bindParam(':rstatus',$rstatus,PDO::PARAM_STR);
$query->bindParam(':rd',$rd,PDO::PARAM_STR);
$query->bindParam(':Pstatus',$Pstatus,PDO::PARAM_STR);
$query->bindParam(':ustatus',$ustatus,PDO::PARAM_STR);
$query->bindParam(':bkid1',$bkid1,PDO::PARAM_STR);
$query->bindParam(':dec1',$dec1,PDO::PARAM_STR);
$query->bindParam(':sid1',$sid1,PDO::PARAM_STR);
$query->execute();
}
else
{
    $sql1="update tblissuedbookdetails set fine=:fine,Pstatus=:Pstatus where id=:rid";
$query = $dbh->prepare($sql1);
$query->bindParam(':rid',$rid,PDO::PARAM_STR);
$query->bindParam(':fine',$fine,PDO::PARAM_STR);
$query->bindParam(':pstatus',$pstatus,PDO::PARAM_STR);
}

$_SESSION['msg']="Book Returned successfully";
header('location:manage-issued-books.php');
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Online Library Management System | Issued Book Details</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<script>
// function for get student name
function getstudent() {
$("#loaderIcon").show();
jQuery.ajax({
url: "get_student.php",
data:'FingerID='+$("#FingerID").val(),
type: "POST",
success:function(data){
$("#get_student_name").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}

//function for book details
function getbook() {
$("#loaderIcon").show();
jQuery.ajax({
url: "get_book.php",
data:'Book_ID='+$("#Book_ID").val(),
type: "POST",
success:function(data){
$("#get_book_name").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}

</script> 
<style type="text/css">
  .others{
    color:red;
}

</style>


</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');
?>
<!-- MENU SECTION END-->
   
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Issued Book Details</h4>
                
                            </div>

</div>
<div class="row">
<div class="col-md-10 col-sm-6 col-xs-12 col-md-offset-1">
<div class="panel panel-info">
<div class="panel-heading">
Issued Book Details
</div>
<div class="panel-body">
<form role="form" method="post">
<?php 
$rid=intval($_GET['rid']);
$sql = "SELECT tblstudents.FullName,tblstudents.StudentId as sid, tblstudents.bookcount as bc,tblbooks.id as bid,tblbooks.BookName,tblbooks.ISBNNumber,tblissuedbookdetails.IssuesDate,tblissuedbookdetails.DueDate,tblissuedbookdetails.ReturnedDate,tblissuedbookdetails.id as rid,tblissuedbookdetails.fine,tblissuedbookdetails.ReturnStatus,tblissuedbookdetails.Pstatus from  tblissuedbookdetails join tblstudents on tblstudents.FingerID=tblissuedbookdetails.FingerID or tblstudents.StudentId=tblissuedbookdetails.StudentId join tblbooks on tblbooks.Book_ID=tblissuedbookdetails.Book_ID or tblbooks.id=tblissuedbookdetails.BookId where tblissuedbookdetails.id=:rid";
$query = $dbh -> prepare($sql);
$query->bindParam(':rid',$rid,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{       $_SESSION['bkid']=$result->bid;
         $bc=$result->bc;
         $_SESSION['dec']=$bc-1;
         $_SESSION['sid']=$result->sid; 
         $_SESSION['rt']=$ReturnStatus;       ?>                                      
                   



<div class="form-group">
<label>Student Name :</label>
<?php echo htmlentities($result->FullName);?>
</div>

<div class="form-group">
<label>Book Name :</label>
<?php echo htmlentities($result->BookName);?>
</div>


<div class="form-group">
<label>ISBN :</label>
<?php echo htmlentities($result->ISBNNumber);?>
</div>

<div class="form-group">
<label>Book Issued Date :</label>
<?php echo htmlentities($result->IssuesDate);?>
</div>

<div class="form-group">
<label>Book Due Date :</label>
<?php echo htmlentities($result->DueDate);?>
</div>

<div class="form-group">
<label>Book Returned Date :</label>
<?php if($result->ReturnedDate=="")
                                            {
                                                echo htmlentities("Not Return Yet");
                                            } else {


                                            echo htmlentities($result->ReturnedDate);
}
                                            ?>
</div>

<div class="form-group">
<label>Fine (in USD) :</label>
<?php 
if( $result->Pstatus==1 or $result->ReturnStatus==0 )
{?>
<input class="form-control" type="text" name="fine" id="fine"  required />

<?php }else {
echo htmlentities($result->fine);
}
?>
</div>
 <?php if($result->RetrunStatus==0){?>

<button type="submit" name="return" id="submit" class="btn btn-info">Pay or Return Book</button>

 </div>

<?php }}} ?>
                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
   
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>

</body>
</html>
<?php } ?>
