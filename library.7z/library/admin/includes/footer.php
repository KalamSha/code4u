   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                  &copy; 2020 Wireless Biometric Self Check System |Designed by : AKMS</a>  
                </div>

            </div>
        </div>
    </section>
