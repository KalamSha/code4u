<?php
include('includes/config.php');
$sql="SELECT tblissuedbookdetails.DueDate, tblissuedbookdetails.ReturedDate WHERE fine IS NULL";
$query=$dbh->prepare($sql);
$query->execute();
$result=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
	echo $result;
/*foreach($results as $result)
{                    
}
echo($result->DueDate);
echo($result->$ReturedDate);
}
?>*.



<?php
/* $sql = "SELECT tblstudents.FullName,tblbooks.BookName,tblbooks.ISBNNumber,tblissuedbookdetails.IssuesDate,tblissuedbookdetails.DueDate,tblissuedbookdetails.ReturnedDate,tblissuedbookdetails.id as rid from  tblissuedbookdetails join tblstudents on tblstudents.FingerID=tblissuedbookdetails.FingerID or tblstudents.StudentId=tblissuedbookdetails.StudentId  join tblbooks on tblbooks.Book_ID=tblissuedbookdetails.Book_ID or tblbooks.id=tblissuedbookdetails.BookId order by tblissuedbookdetails.id desc"; 
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{  echo $dd=$result->DueDate;
*/
?>