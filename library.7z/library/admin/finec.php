<?php

error_reporting(0);
include('includes/config.php');
/*
$sql = "SELECT tblissuedbookdetails.DueDate,tblissuedbookdetails.ReturnedDate WHERE tblissuedbookdetails.id = 259 AND tblissuedbookdetails.fine IS NULL";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{   
echo $rd=$result->ReturnedDate;
echo $dd=$result->DueDate;

*/

//echo "<table style='border: solid 1px black;'>";
//echo "<tr><th>Id</th><th>ReturnedDate</th><th>DueDate</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

/*$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";*/

try {
    //$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $dbh->prepare("SELECT id, ReturnedDate, DueDate FROM tblissuedbookdetails WHERE fine IS NULL and id=259");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
      }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";
?>

      