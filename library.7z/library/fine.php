<?php
include('includes/config.php');
if($_GET['FingerID'] != '' and  $_GET['Book_ID'] != '')
{

$FingerID=($_GET['FingerID']);
 $Book_ID=($_GET['Book_ID']);
 $sql="SELECT DueDate from tblissuedbookdetails where FingerID='".$FingerID."' and Book_ID='".$Book_ID."' and ReturnedDate IS NULL";
 $query = $dbh -> prepare($sql);
 $query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
foreach ($results as $result) 
 # code...
$dd=$result->DueDate;

 $sql="SELECT bookcount,book1,book2 from tblstudents where FingerID='".$FingerID."'";
 $query = $dbh -> prepare($sql);
 $query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
foreach ($results as $result) {
 $bc=$result->bookcount;
$bk1=$result->book1;
$bk2=$result->book2;

date_default_timezone_set('Asia/Kolkata');
$timestamp=time();
 $rd=date("yy-m-d h:i:s",$timestamp);
$diff=strtotime($rd)-strtotime($dd);

 $dp = floor($diff / (60 * 60 * 24));
if ($diff<0)
{
	$fine=0;
	$GLOBALS['fine'];
}
if($dp>=1&& $dp<=7)
{
$fine=$dp;
	$GLOBALS['fine'];
}
else if($dp>7&& $dp<=14)
{
    $amo1=$dp-7;
    $nwd=$amo1*2;
    $fine=7+$nwd;
    $GLOBALS['fine'];
}
elseif ($dp>14) {
  $amo2=$dp-14;
  $nwd=$amo2*5;
  $fine=21+$nwd;
  $GLOBALS['fine'];   
    }

 $rstatus=1;
 $ustatus=NULL;
 $dec=$bc-1;
 if($fine>1)
 {
 	$pstatus=1;
 	$GLOBALS['pstatus'];
 }
 $sql="update tblissuedbookdetails set ReturnedDate=:rd,ReturnStatus=:rstatus,fine=:fine,Pstatus=:pstatus WHERE FingerID='".$FingerID."' and Book_ID='".$Book_ID."' and ReturnStatus IS NULL;update tblbooks set status=:ustatus where Book_ID='".$Book_ID."';update tblstudents set bookcount=:dec WHERE FingerID='".$FingerID."'";
$query = $dbh->prepare($sql);
$query->bindParam(':rd',$rd,PDO::PARAM_STR);
$query->bindParam(':rstatus',$rstatus,PDO::PARAM_STR);
$query->bindParam(':fine',$fine,PDO::PARAM_STR);
$query->bindParam(':pstatus',$pstatus,PDO::PARAM_STR);
$query->bindParam(':ustatus',$ustatus,PDO::PARAM_STR);
$query->bindParam(':dec',$dec,PDO::PARAM_STR);
$query->execute();

if($bk1==$Book_ID)
{
	$sql="update tblstudents set book1=NULL WHERE FingerID='".$FingerID."'";
$query = $dbh->prepare($sql);
$query->execute();
}
else{
	$sql="update tblstudents set book2=NULL WHERE FingerID='".$FingerID."'";
$query = $dbh->prepare($sql);
$query->execute();
}
}
}
else echo "sorry";
?>