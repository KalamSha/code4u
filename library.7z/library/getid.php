<?php
include('includes/config.php');

$FingerID='';
 $Book_ID='';

if($_GET['FingerID'] != '' and  $_GET['Book_ID'] != '')
{

 $FingerID=($_GET['FingerID']);
 $Book_ID=($_GET['Book_ID']);

$ustatus=1;
	date_default_timezone_set('Asia/Kolkata');
$timestamp=time();
$cd=date("yy-m-d h:i:s",$timestamp);


$dd=date("yy-m-d h:i:s",strtotime($cd.'+ 14 days'));


$sql="SELECT bookcount from tblstudents where FingerID='".$FingerID."'";
 $query = $dbh -> prepare($sql);
 $query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
foreach ($results as $result)
 {
$bc= $result->bookcount;
if($bc<2)
{
$ustatus=1;
$inc=$bc+1;
$sql= "UPDATE tblbooks set status=:ustatus where Book_ID='$Book_ID';update tblstudents set bookcount=:inc where FingerID='$FingerID'";	
		$query = $dbh->prepare($sql);
$query->bindParam(':ustatus',$ustatus,PDO::PARAM_STR);
$query->bindParam(':inc',$inc,PDO::PARAM_STR);
$query->execute();
$sql = "insert into tblissuedbookdetails set Book_ID='".$Book_ID."', FingerID='".$FingerID."',DueDate='$dd'";
$query = $dbh->prepare($sql);
$query->bindParam(':FingerID',$FingerID,PDO::PARAM_STR);
$query->bindParam(':Book_ID',$Book_ID,PDO::PARAM_STR);
$query->bindParam(':dd',$dd,PDO::PARAM_STR);
$query->execute();

}
else echo "no more space";
}
}
else echo "sorry "; 
?>